// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <windows.h>

#define _CRTDBG_MAP_ALLOC
#include <cstdlib>
#include <crtdbg.h>

#include <stdio.h>
#include <tchar.h>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <conio.h>
#include <string>
#include <vector>

#include "Console.h"



using namespace System;
using namespace std;